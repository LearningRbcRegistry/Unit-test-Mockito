package mockito2;

public class NotAuthenticatedException extends Exception {
	
	public NotAuthenticatedException(){
		super("Could Not Authenticated!");
	}

}
