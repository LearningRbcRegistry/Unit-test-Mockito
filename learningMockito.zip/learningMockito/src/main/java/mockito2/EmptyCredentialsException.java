package mockito2;

public class EmptyCredentialsException extends Exception {	     

	    public EmptyCredentialsException() {
	        super("Empty credentials!");
	    }
}